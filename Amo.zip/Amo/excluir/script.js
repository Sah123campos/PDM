// Adicionar animação aos links do rodapé
document.addEventListener('DOMContentLoaded', () => {
    const footerLinks = document.querySelectorAll('footer a');

    footerLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            // Prevent default navigation for demonstration
            event.preventDefault();

            // Remove animation class from any previously clicked link
            document.querySelectorAll('.footer-link-animated').forEach(animatedLink => {
                animatedLink.classList.remove('footer-link-animated');
            });

            // Add animation class to the clicked link
            link.classList.add('footer-link-animated');

            // Optional: Remove the class after the animation finishes
            link.addEventListener('animationend', () => {
                link.classList.remove('footer-link-animated');
            }, { once: true });
        });
    });
}); 