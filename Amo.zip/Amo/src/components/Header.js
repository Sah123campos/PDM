import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Dimensions, Image } from 'react-native';

const { width } = Dimensions.get('window');
const isTablet = width >= 768;
const isMobile = width < 768;

/** @param {{ navigation: any }} props */
const Header = ({ navigation }) => {
  const menuItems = [
    { name: 'Home', title: 'INTRODUÇÃO', screen: 'Home' },
    { name: 'Neurodiversidade', title: 'O QUE É NEURODIVERSIDADE', screen: 'Neurodiversidade' },
    { name: 'Legislacao', title: 'LEGISLAÇÃO', screen: 'Legislacao' },
    { name: 'Capacitismo', title: 'CAPACITISMO', screen: 'Capacitismo' },
    { name: 'Relatos', title: 'RELATOS', screen: 'Relatos' },
    { name: 'Desafios', title: 'DESAFIOS', screen: 'Desafios' },
    { name: 'Sobre', title: 'SOBRE', screen: 'Sobre' },
    { name: 'Contato', title: 'CONTATO', screen: 'Contato' },
  ];

  return (
    <View style={styles.header}>
      <View style={styles.container}>
        <Text style={styles.logo}>+ NeuroInclusão</Text>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          style={styles.navScroll}
          contentContainerStyle={styles.navContainer}
        >
          {menuItems.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={styles.navItem}
              onPress={() => navigation.navigate(item.screen)}
            >
              <Text style={[
                styles.navText,
                item.name === 'Contato' && styles.contactButton
              ]}>
                {item.title}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#673ab7',
    paddingVertical: 12,
  },
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: isTablet ? 20 : 15,
    width: '100%',
  },
  logo: {
    fontSize: isTablet ? 16 : 14,
    fontWeight: 'bold',
    color: 'white',
    flexShrink: 0,
  },
  navScroll: {
    flex: 1,
    marginLeft: isTablet ? 20 : 10,
  },
  navContainer: {
    alignItems: 'center',
    paddingRight: isTablet ? 20 : 10,
  },
  navItem: {
    marginLeft: isTablet ? 15 : 8,
    paddingVertical: 5,
  },
  navText: {
    color: 'white',
    fontSize: isTablet ? 11 : 10,
    fontWeight: '500',
  },
  contactButton: {
    backgroundColor: 'white',
    color: '#673ab7',
    paddingHorizontal: isTablet ? 12 : 8,
    paddingVertical: isTablet ? 6 : 4,
    borderRadius: 4,
    fontWeight: 'bold',
  },
});

export default Header;

