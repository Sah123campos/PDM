import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Linking, Dimensions, SafeAreaView, Alert } from 'react-native';

const { width } = Dimensions.get('window');
const isTablet = width >= 768;
const isMobile = width < 768;

/** @param {{ navigation: any }} props */
const Footer = ({ navigation }) => {
  const handleWhatsAppPress = () => {
    const phoneNumber = '5516996046548'; // Número do WhatsApp com código do país
    const whatsappUrl = `https://wa.me/${phoneNumber}`;

    Linking.openURL(whatsappUrl).catch(() => {
      Alert.alert('Erro', 'Não foi possível abrir o WhatsApp.');
    });
  };

  const handleGmailRedirect = () => {
    const recipient = 'inclusaoneuro@gmail.com'; // Email do destinatário
    const subject = encodeURIComponent('Assunto padrão'); // Substitua pelo assunto desejado
    const body = encodeURIComponent('Corpo da mensagem padrão'); // Substitua pelo corpo desejado
    const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=${recipient}&su=${subject}&body=${body}`;

    Linking.openURL(gmailUrl).catch(() => {
      Alert.alert('Erro', 'Não foi possível abrir o Gmail no navegador.');
    });
  };
        
  return (
    <SafeAreaView style={styles.footer}>
      <View style={styles.container}>
        <View style={styles.footerSection}>
          <Text style={styles.sectionTitle}>NeuroInclusão</Text>
          <Text style={styles.sectionText}>
            Promovendo a inclusão de pessoas neurodivergentes e{'\n'}com deficiência no mercado de trabalho.
          </Text>
        </View>
        
        <View style={styles.footerSection}>
          <Text style={styles.sectionTitle}>Links Úteis</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Sobre')}>
            <Text style={styles.linkText}>Sobre nós</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Contato')}>
            <Text style={styles.linkText}>Contato</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.footerSection}>
          <Text style={styles.sectionTitle}>Contato</Text>
          <TouchableOpacity onPress={handleWhatsAppPress}>
            <Text style={styles.linkText}>WhatsApp</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleGmailRedirect}>
            <Text style={styles.linkText}>Gmail</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.copyright}>
        <Text style={styles.copyrightText}>
          © 2025 NeuroInclusão. Todos os direitos reservados.
        </Text>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  footer: {
    backgroundColor: '#673ab7',
    paddingVertical: isMobile ? 12 : 14,
    paddingBottom: isMobile ? 16 : 12,
    width: '100%',
  },
  container: {
    flexDirection: isTablet ? 'row' : 'column',
    justifyContent: 'center',
    alignItems: 'center',
    width: isTablet ? '85%' : '95%',
    marginHorizontal: isTablet ? '7.5%' : '2.5%',
    marginBottom: isMobile ? 10 : 20,
    flexWrap: 'wrap',
  },
  footerSection: {
    flex: 1,
    minWidth: isTablet ? 180 : 150,
    marginRight: isTablet ? 20 : 0,
    marginBottom: isMobile ? 20 : 0,
    alignItems: 'center',
  },
  sectionTitle: {
    color: 'white',
    fontSize: isTablet ? 16 : 14,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  sectionText: {
    color: '#e1bee7',
    fontSize: isTablet ? 12 : 11,
    lineHeight: isTablet ? 18 : 16,
    textAlign: 'center',
  },
  linkText: {
    color: '#e1bee7',
    fontSize: isTablet ? 12 : 11,
    marginBottom: 10,
    textDecorationLine: 'underline',
    textAlign: 'center',
  },
  copyright: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.3)',
    paddingTop: 20,
    alignItems: 'center',
    width: isTablet ? '85%' : '95%',
    marginHorizontal: isTablet ? '7.5%' : '2.5%',
  },
  copyrightText: {
    color: '#e1bee7',
    fontSize: isTablet ? 10 : 9,
    textAlign: 'center',
  },
});

export default Footer;

