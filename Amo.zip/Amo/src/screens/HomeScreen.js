import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  useWindowDimensions
} from 'react-native';
import Header from '../components/Header';
import Footer from '../components/Footer';

// isTablet / isMobile will be computed per-render using useWindowDimensions

/** @param {{ navigation: any }} props */
const HomeScreen = ({ navigation }) => {
  const { width } = useWindowDimensions();
  const isTablet = width >= 768;
  const isMobile = width < 768;
  const styles = createStyles(isTablet, isMobile);

  return (
    <View style={styles.container}>
      <Header navigation={navigation} />

      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
        <View style={styles.main}>
          {isMobile && (
            <View style={styles.heroImageMobileContainer}>
              {/* @ts-ignore */}
              <Image source={require('../styles/logo.png')} style={styles.heroLogo} resizeMode="contain" />
            </View>
          )}
          <View style={styles.heroSection}>
            <View style={styles.heroContent}>
              <Text style={styles.heroTitle}>
                Neurodiversidade e PCDs no{'\n'}Mercado de Trabalho
              </Text>
              <Text style={styles.heroDescription}>
                Bem-vindo ao nosso portal sobre inclusão de pessoas neurodivergentes e
                com deficiência no ambiente profissional. Aqui você encontrará
                informações sobre legislação, desafios, relatos e muito mais.
              </Text>
              <TouchableOpacity
                style={styles.saibaMaisBtn}
                onPress={() => navigation.navigate('Neurodiversidade')}
              >
                <Text style={styles.saibaMaisText}>SAIBA MAIS</Text>
              </TouchableOpacity>
            </View>
            {!isMobile && <View style={{ height: 24 }} />}
            {!isMobile && (
              <View style={styles.heroImage}>
                {/* @ts-ignore */}
                <Image source={require('../styles/logo.png')} style={styles.heroLogo} resizeMode="contain" />
              </View>
            )}
          </View>
        </View>
      </ScrollView>

      <Footer navigation={navigation} />
    </View>
  );
};

/** @param {boolean} isTablet 
    @param {boolean} isMobile */
function createStyles(isTablet, isMobile) {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
    },
    scrollView: {
      flex: 1,
    },
    scrollContent: {
      flexGrow: 1,
      justifyContent: 'flex-start',
      paddingBottom: 20,
    },
    main: {
      // não usar flex:1 para evitar que a área principal cresça e gere espaço em branco
      flex: 0,
      paddingHorizontal: isTablet ? 40 : 20,
      paddingTop: 20,
    },
    heroSection: {
      flexDirection: isTablet ? 'row' : 'column',
      alignItems: 'center',
      justifyContent: 'space-between',
      backgroundColor: '#f8f9fa',
      borderRadius: 12,
      padding: isTablet ? 36 : 26,
      marginBottom: 28,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.1,
      shadowRadius: 8,
      elevation: 4,
      overflow: 'hidden',
    },
    heroContent: {
      flex: 1,
      paddingRight: isTablet ? 40 : 0,
      paddingBottom: isMobile ? 24 : 24,
    },
    heroTitle: {
      color: '#5e35b1',
      fontSize: isTablet ? 24 : 20,
      fontWeight: 'bold',
      marginBottom: 24,
      lineHeight: isTablet ? 32 : 28,
      textAlign: isMobile ? 'center' : 'left',
    },
    heroDescription: {
      fontSize: isTablet ? 14 : 13,
      lineHeight: isTablet ? 22 : 20,
      marginBottom: 24,
      color: '#555',
      textAlign: isMobile ? 'center' : 'left',
    },
    saibaMaisBtn: {
      backgroundColor: '#03a9f4',
      paddingHorizontal: 20,
      paddingVertical: 10,
      borderRadius: 5,
      alignSelf: isMobile ? 'center' : 'flex-start',
      marginBottom: 24,
    },
    saibaMaisText: {
      color: 'white',
      fontSize: 14,
      fontWeight: 'normal',
    },
    heroImage: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#ede7f6',
      borderRadius: 8,
      padding: isTablet ? 32 : 24,
      minHeight: isTablet ? 320 : 260,
      width: isMobile ? '100%' : 'auto',
    },
    heroLogo: {
      width: isTablet ? 300 : 180,
      height: isTablet ? 300 : 180,
    },
    heroImageMobileContainer: {
      alignItems: 'center',
      marginBottom: 12,
    },
  });
}

export default HomeScreen;