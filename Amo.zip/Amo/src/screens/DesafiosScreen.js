import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Dimensions 
} from 'react-native';
import Header from '../components/Header';
import Footer from '../components/Footer';

const { width } = Dimensions.get('window');

/** @param {{ navigation: any }} props */
const DesafiosScreen = ({ navigation }) => {
  const dadosEstatisticos = [
    {
      valor: '8,4%',
      descricao: 'da população\nbrasileira tem algum\ntipo de deficiência\n(IBGE, 2022)',
      icon: '👥'
    },
    {
      valor: '1,2%',
      descricao: 'das pessoas com\ndeficiência estão\nempregadas\nformalmente',
      icon: '📊'
    },
    {
      valor: 'apenas 0,5%',
      descricao: 'dos cargos de\nliderança são\nocupados por PCDs\nou neurodivergentes',
      icon: '📈'
    },
    {
      valor: '1 em cada 6',
      descricao: 'pessoas no mundo\né neurodivergente\n(OMS, 2023)',
      icon: '🌍'
    }
  ];

  const principaisDesafios = [
    {
      title: 'Barreiras na Entrada',
      icon: '🚪',
      desafios: [
        'Processos seletivos não adaptados',
        'Preconceito e discriminação',
        'Falta de oportunidades de estágio',
        'Requisitos que não consideram diferenças'
      ],
      solucoes: [
        'Adaptar processos seletivos'
      ]
    },
    {
      title: 'Ambiente de Trabalho',
      icon: '🏢',
      desafios: [
        'Falta de acessibilidade física',
        'Barreiras na comunicação',
        'Estresse sensorial',
        'Falta de flexibilidade'
      ],
      solucoes: [
        'Implementar adaptações necessárias',
        'Criar canais de comunicação alternativos'
      ]
    },
    {
      title: 'Desenvolvimento Profissional',
      icon: '📚',
      desafios: [
        'Falta de oportunidades de crescimento',
        'Treinamentos não adaptados',
        'Barreiras na promoção',
        'Falta de mentoria'
      ],
      solucoes: [
        'Criar programas de desenvolvimento inclusivos'
      ]
    }
  ];

  const estrategias = [
    {
      title: 'Para Profissionais',
      icon: '💡',
      items: [
        'Buscar autoconhecimento e entender suas necessidades',
        'Desenvolver estratégias de comunicação efetivas',
        'Procurar mentoria e networking',
        'Documentar suas conquistas e habilidades',
        'Buscar formação e certificações relevantes'
      ]
    },
    {
      title: 'Para Empresas',
      icon: '💡',
      items: [
        'Implementar políticas de inclusão',
        'Treinar equipes em diversidade e inclusão',
        'Criar programas de mentoria',
        'Adaptar processos e ambientes',
        'Estabelecer métricas de inclusão'
      ]
    },
    {
      title: 'Para a Sociedade',
      icon: '💡',
      items: [
        'Promover conscientização',
        'Criar redes de apoio',
        'Desenvolver programas de capacitação',
        'Fomentar parcerias entre empresas e instituições',
        'Advogar por políticas públicas inclusivas'
      ]
    }
  ];

  return (
    <View style={styles.container}>
      <Header navigation={navigation} />
      
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Seção de Introdução */}
        <View style={styles.sectionIntro}>
          <Text style={styles.sectionTitle}>Desafios e Soluções</Text>
          <View style={styles.divider} />
          <Text style={styles.sectionDescription}>
            Pessoas neurodivergentes e com deficiência enfrentam diversos desafios no mercado de trabalho.
          </Text>
          <Text style={styles.sectionDescription}>
            Reconhecer e entender esses obstáculos é o primeiro passo para criar ambientes mais inclusivos e acessíveis.
          </Text>
        </View>

        {/* Dados Estatísticos */}
        <View style={styles.dadosSection}>
          <Text style={styles.sectionSubtitle}>Dados Estatísticos</Text>
          <View style={styles.dadosGrid}>
            {dadosEstatisticos.map((dado, index) => (
              <View key={index} style={styles.dadoCard}>
                <View style={styles.dadoIcon}>
                  <Text style={styles.dadoIconText}>{dado.icon}</Text>
                </View>
                <View style={styles.dadoContent}>
                  <Text style={styles.dadoValor}>{dado.valor}</Text>
                  <Text style={styles.dadoDescricao}>{dado.descricao}</Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* Principais Desafios */}
        <View style={styles.desafiosSection}>
          <Text style={styles.sectionSubtitle}>Principais Desafios e Soluções</Text>
          <View style={styles.desafiosGrid}>
            {principaisDesafios.map((desafio, index) => (
              <View key={index} style={styles.desafioCard}>
                <View style={styles.desafioIcon}>
                  <Text style={styles.desafioIconText}>{desafio.icon}</Text>
                </View>
                <Text style={styles.desafioTitle}>{desafio.title}</Text>
                
                <Text style={styles.desafioSubtitulo}>Desafios:</Text>
                {desafio.desafios.map((item, idx) => (
                  <Text key={idx} style={styles.desafioItem}>
                    ⚠️ {item}
                  </Text>
                ))}
                
                <Text style={styles.desafioSubtitulo}>Soluções:</Text>
                {desafio.solucoes.map((item, idx) => (
                  <Text key={idx} style={styles.solucaoItem}>
                    ✅ {item}
                  </Text>
                ))}
              </View>
            ))}
          </View>
        </View>

        {/* Estratégias para Inclusão */}
        <View style={styles.estrategiasSection}>
          <Text style={styles.sectionSubtitle}>Estratégias para Inclusão</Text>
          <View style={styles.estrategiasGrid}>
            {estrategias.map((estrategia, index) => (
              <View key={index} style={styles.estrategiaCard}>
                <Text style={styles.estrategiaTitle}>{estrategia.title}</Text>
                {estrategia.items.map((item, idx) => (
                  <Text key={idx} style={styles.estrategiaItem}>
                    💡 {item}
                  </Text>
                ))}
              </View>
            ))}
          </View>
        </View>

        <Footer navigation={navigation} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f7f6',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  sectionIntro: {
    backgroundColor: 'white',
    margin: 20,
    padding: 20,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  sectionTitle: {
    color: '#5e35b1',
    fontSize: width < 768 ? 20 : 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  divider: {
    width: 60,
    height: 3,
    backgroundColor: '#6C3DF4',
    alignSelf: 'center',
    marginBottom: 15,
    borderRadius: 2,
  },
  sectionDescription: {
    fontSize: width < 768 ? 13 : 14,
    lineHeight: width < 768 ? 20 : 22,
    color: '#333',
    textAlign: 'center',
    marginBottom: 10,
  },
  dadosSection: {
    margin: 20,
  },
  desafiosSection: {
    margin: 20,
  },
  estrategiasSection: {
    margin: 20,
  },
  sectionSubtitle: {
    color: '#5e35b1',
    fontSize: width < 768 ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  dadosGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  dadoCard: {
    backgroundColor: '#f4f0ff',
    borderRadius: 20,
    padding: 15,
    marginBottom: 15,
    width: width < 768 ? '100%' : '48%',
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#6C3DF4',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.07,
    shadowRadius: 12,
    elevation: 2,
  },
  dadoIcon: {
    width: 50,
    height: 50,
    backgroundColor: '#ede7f6',
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  dadoIconText: {
    fontSize: 24,
  },
  dadoContent: {
    flex: 1,
  },
  dadoValor: {
    color: '#7C4DFF',
    fontSize: width < 768 ? 14 : 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  dadoDescricao: {
    color: '#222',
    fontSize: width < 768 ? 11 : 12,
    lineHeight: width < 768 ? 15 : 16,
  },
  desafiosGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  desafioCard: {
    backgroundColor: '#f7f3ff',
    borderWidth: 2,
    borderColor: '#b39dff',
    borderRadius: 24,
    padding: 15,
    marginBottom: 15,
    width: width < 768 ? '100%' : '48%',
    shadowColor: '#6C3DF4',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.08,
    shadowRadius: 24,
    elevation: 2,
  },
  desafioIcon: {
    alignSelf: 'center',
    marginBottom: 10,
  },
  desafioIconText: {
    fontSize: 32,
  },
  desafioTitle: {
    color: '#6C3DF4',
    fontSize: width < 768 ? 14 : 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 15,
  },
  desafioSubtitulo: {
    color: '#6C3DF4',
    fontSize: width < 768 ? 13 : 14,
    fontWeight: 'bold',
    marginTop: 10,
    marginBottom: 5,
  },
  desafioItem: {
    color: '#333',
    fontSize: width < 768 ? 11 : 12,
    lineHeight: width < 768 ? 15 : 16,
    marginBottom: 3,
  },
  solucaoItem: {
    color: '#333',
    fontSize: width < 768 ? 11 : 12,
    lineHeight: width < 768 ? 15 : 16,
    marginBottom: 3,
  },
  estrategiasGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  estrategiaCard: {
    backgroundColor: '#f4f0ff',
    borderWidth: 2,
    borderColor: '#b39dff',
    borderRadius: 24,
    padding: 15,
    marginBottom: 15,
    width: width < 768 ? '100%' : '48%',
    shadowColor: '#6C3DF4',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.08,
    shadowRadius: 24,
    elevation: 2,
  },
  estrategiaTitle: {
    color: '#6C3DF4',
    fontSize: width < 768 ? 14 : 16,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  estrategiaItem: {
    color: '#333',
    fontSize: width < 768 ? 11 : 12,
    lineHeight: width < 768 ? 15 : 16,
    marginBottom: 8,
  },
});

export default DesafiosScreen;

