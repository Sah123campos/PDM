import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Dimensions 
} from 'react-native';
import Header from '../components/Header';
import Footer from '../components/Footer';

const { width } = Dimensions.get('window');

/** @param {{ navigation: any }} props */
const LegislacaoScreen = ({ navigation }) => {
  const principaisLeis = [
    {
      title: 'Lei de Cotas (Lei nº 8.213/91)',
      description: 'Estabelece a obrigatoriedade de contratação de pessoas com deficiência por empresas com 100 ou mais empregados, com percentuais que variam de 2% a 5% do total de empregados.',
      detalhes: [
        'Empresas com 100 a 200 empregados: 2%',
        'Empresas com 201 a 500 empregados: 3%',
        'Empresas com 501 a 1000 empregados: 4%',
        'Empresas com mais de 1000 empregados: 5%'
      ]
    },
    {
      title: 'Lei Brasileira de Inclusão (Lei nº 13.146/15)',
      description: 'Estatuto da Pessoa com Deficiência, que garante direitos fundamentais e estabelece diretrizes para a inclusão social.',
      detalhes: [
        'Garantia de igualdade de oportunidades',
        'Não discriminação no ambiente de trabalho',
        'Acessibilidade em processos seletivos',
        'Adaptações razoáveis no ambiente de trabalho'
      ]
    },
    {
      title: 'Convenção sobre os Direitos das Pessoas com Deficiência',
      description: 'Tratado internacional ratificado pelo Brasil que estabelece direitos fundamentais para pessoas com deficiência.',
      detalhes: [
        'Direito ao trabalho em condições de igualdade',
        'Proibição de discriminação',
        'Acesso a programas de formação profissional',
        'Promoção de oportunidades de emprego'
      ]
    }
  ];

  const direitosFundamentais = [
    {
      title: 'Direitos Trabalhistas',
      items: [
        'Estabilidade provisória após a contratação',
        'Auxílio-inclusão para pessoas com deficiência moderada ou grave',
        'Auxílio-reabilitação psicossocial',
        'Aposentadoria por invalidez'
      ]
    },
    {
      title: 'Adaptações no Ambiente de Trabalho',
      items: [
        'Adequação do posto de trabalho',
        'Fornecimento de tecnologias assistivas',
        'Flexibilidade de horário quando necessário',
        'Acompanhante especializado quando requerido'
      ]
    },
    {
      title: 'Processos Seletivos',
      items: [
        'Acessibilidade nas provas e entrevistas',
        'Tempo adicional para realização de provas',
        'Adaptação de materiais e recursos',
        'Intérprete de Libras quando necessário'
      ]
    }
  ];

  return (
    <View style={styles.container}>
      <Header navigation={navigation} />
      
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Seção de Introdução */}
        <View style={styles.sectionIntro}>
          <Text style={styles.sectionTitle}>Legislação e Direitos</Text>
          <View style={styles.divider} />
          <Text style={styles.sectionDescription}>
            O Brasil possui um conjunto robusto de leis e regulamentações que garantem os direitos das pessoas
            com deficiência e neurodivergentes no mercado de trabalho. Estas leis visam promover a inclusão e
            combater a discriminação.
          </Text>
        </View>

        {/* Principais Leis */}
        <View style={styles.leisSection}>
          <Text style={styles.sectionSubtitle}>Principais Leis</Text>
          <View style={styles.cardsContainer}>
            {principaisLeis.map((lei, index) => (
              <View key={index} style={styles.leiCard}>
                <Text style={styles.leiTitle}>{lei.title}</Text>
                <Text style={styles.leiDescription}>{lei.description}</Text>
                <Text style={styles.detalhesTitle}>Detalhes importantes:</Text>
                {lei.detalhes.map((detalhe, idx) => (
                  <Text key={idx} style={styles.detalheItem}>• {detalhe}</Text>
                ))}
              </View>
            ))}
          </View>
        </View>

        {/* Direitos Fundamentais */}
        <View style={styles.direitosSection}>
          <Text style={styles.sectionSubtitle}>Direitos Fundamentais</Text>
          <View style={styles.cardsContainer}>
            {direitosFundamentais.map((direito, index) => (
              <View key={index} style={styles.direitoCard}>
                <Text style={styles.direitoTitle}>{direito.title}</Text>
                {direito.items.map((item, idx) => (
                  <Text key={idx} style={styles.direitoItem}>• {item}</Text>
                ))}
              </View>
            ))}
          </View>
        </View>

        <Footer navigation={navigation} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f7f6',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  sectionIntro: {
    backgroundColor: 'white',
    margin: 20,
    padding: 20,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  sectionTitle: {
    color: '#5e35b1',
    fontSize: width < 768 ? 20 : 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  divider: {
    width: 60,
    height: 3,
    backgroundColor: '#6C3DF4',
    alignSelf: 'center',
    marginBottom: 15,
    borderRadius: 2,
  },
  sectionDescription: {
    fontSize: width < 768 ? 13 : 14,
    lineHeight: width < 768 ? 20 : 22,
    color: '#333',
    textAlign: 'center',
  },
  leisSection: {
    backgroundColor: '#f4f7f6',
    margin: 20,
    padding: 20,
    borderRadius: 8,
  },
  direitosSection: {
    backgroundColor: '#f4f7f6',
    margin: 20,
    padding: 20,
    borderRadius: 8,
  },
  sectionSubtitle: {
    color: '#5e35b1',
    fontSize: width < 768 ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  cardsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  leiCard: {
    backgroundColor: '#f7f3ff',
    borderWidth: 2,
    borderColor: '#b39dff',
    borderRadius: 18,
    padding: 15,
    marginBottom: 15,
    width: width < 768 ? '100%' : '48%',
    shadowColor: '#6C3DF4',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 2,
  },
  leiTitle: {
    color: '#6C3DF4',
    fontSize: width < 768 ? 14 : 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  leiDescription: {
    color: '#333',
    fontSize: width < 768 ? 12 : 13,
    lineHeight: width < 768 ? 16 : 18,
    marginBottom: 10,
  },
  detalhesTitle: {
    color: '#6C3DF4',
    fontSize: width < 768 ? 13 : 14,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  detalheItem: {
    color: '#333',
    fontSize: width < 768 ? 11 : 12,
    lineHeight: width < 768 ? 15 : 16,
    marginBottom: 3,
  },
  direitoCard: {
    backgroundColor: '#f7f3ff',
    borderWidth: 2,
    borderColor: '#b39dff',
    borderRadius: 18,
    padding: 15,
    marginBottom: 15,
    width: width < 768 ? '100%' : '48%',
    shadowColor: '#6C3DF4',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 2,
  },
  direitoTitle: {
    color: '#6C3DF4',
    fontSize: width < 768 ? 14 : 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  direitoItem: {
    color: '#333',
    fontSize: width < 768 ? 11 : 12,
    lineHeight: width < 768 ? 15 : 16,
    marginBottom: 3,
  },
});

export default LegislacaoScreen;

