import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TextInput,
  TouchableOpacity,
  Alert,
  Linking,
  Dimensions 
} from 'react-native';
import Header from '../components/Header';
import Footer from '../components/Footer';

const { width } = Dimensions.get('window');

/** @param {{ navigation: any }} props */
const ContatoScreen = ({ navigation }) => {
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    assunto: '',
    mensagem: '',
    newsletter: false
  });
  const [emailError, setEmailError] = useState('');

  /** @param {string} field 
      @param {string | boolean} value */
  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));

    if (field === 'email' && typeof value === 'string') {
      const emailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
      if (!emailRegex.test(value)) {
        setEmailError('Endereço de e-mail inválido');
      } else {
        setEmailError('');
      }
    }
  };

  const handleSubmit = () => {
    if (!formData.nome || !formData.email || !formData.assunto || !formData.mensagem) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    Alert.alert(
      'Sucesso!', 
      'Sua mensagem foi enviada com sucesso. Entraremos em contato em breve!',
      [
        {
          text: 'OK',
          onPress: () => {
            setFormData({
              nome: '',
              email: '',
              assunto: '',
              mensagem: '',
              newsletter: false
            });
          }
        }
      ]
    );
  };

  const handleEmailPress = () => {
    Linking.openURL('mailto:');
  };

  const handlePhonePress = () => {
    Linking.openURL('tel:+5516996046548');
  };

  const handleGmailRedirect = () => {
    if (!formData.nome || !formData.email || !formData.assunto || !formData.mensagem) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    if (emailError) {
      Alert.alert('Erro', 'Por favor, corrija o e-mail antes de continuar.');
      return;
    }

    const subject = encodeURIComponent(formData.assunto);
    const body = encodeURIComponent(`Nome: ${formData.nome}\nEmail: ${formData.email}\nMensagem: ${formData.mensagem}`);
    const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=inclusaoneuro@gmail.com&su=${subject}&body=${body}`;

    Linking.openURL(gmailUrl).catch(() => {
      Alert.alert('Erro', 'Não foi possível abrir o Gmail no navegador.');
    });
  };

  const faqItems = [
    {
      question: 'Como posso contribuir com o projeto?',
      answer: 'Você pode contribuir compartilhando sua experiência, sugerindo melhorias no site, ou divulgando nosso conteúdo para ajudar outras pessoas.'
    },
    {
      question: 'Vocês oferecem consultoria para empresas?',
      answer: 'Sim! Oferecemos orientações sobre como implementar políticas de inclusão e criar ambientes mais acessíveis. Entre em contato para saber mais.'
    },
    {
      question: 'Posso compartilhar meu relato anonimamente?',
      answer: 'Claro! Respeitamos sua privacidade. Você pode compartilhar sua história de forma anônima se preferir.'
    },
    {
      question: 'Vocês têm parcerias com outras organizações?',
      answer: 'Estamos sempre abertos a parcerias com organizações que compartilham nossa missão de promover a inclusão.'
    }
  ];

  return (
    <View style={styles.container}>
      <Header navigation={navigation} />
      
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Seção de Introdução */}
        <View style={styles.contatoIntro}>
          <Text style={styles.contatoTitle}>Entre em Contato</Text>
          <Text style={styles.contatoDescription}>
            Tem alguma dúvida, sugestão ou quer compartilhar sua experiência? 
            Estamos aqui para ajudar e ouvir você. Entre em contato conosco!
          </Text>
        </View>

        {/* Informações de Contato e Formulário */}
        <View style={styles.contatoContent}>
          <View style={styles.contatoGrid}>
            {/* Informações de Contato */}
            <View style={styles.contatoInfo}>
              <Text style={styles.infoTitle}>Informações de Contato</Text>
              
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Email</Text>
                <TouchableOpacity onPress={handleEmailPress}>
                  <Text style={styles.infoLink}>inclusaoneuro@gmail.com</Text>
                </TouchableOpacity>
              </View>
              
              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Telefone</Text>
                <TouchableOpacity onPress={handlePhonePress}>
                  <Text style={styles.infoLink}>+55 16 99604-6548</Text>
                </TouchableOpacity>
              </View>

              <View style={styles.infoItem}>
                <Text style={styles.infoLabel}>Horário de Atendimento</Text>
                <Text style={styles.infoText}>Segunda a Sexta: 9h às 18h</Text>
              </View>
            </View>

            {/* Formulário de Contato */}
            <View style={styles.contatoForm}>
              <Text style={styles.formTitle}>Envie sua Mensagem</Text>
              
              <View style={styles.formGroup}>
                <Text style={styles.label}>Nome Completo *</Text>
                <TextInput
                  style={styles.input}
                  value={formData.nome}
                  onChangeText={(value) => handleInputChange('nome', value)}
                  placeholder="Seu nome completo"
                />
              </View>
              
              <View style={styles.formGroup}>
                <Text style={styles.label}>Email *</Text>
                <TextInput
                  style={[styles.input, emailError ? styles.inputError : null]}
                  value={formData.email}
                  onChangeText={(value) => handleInputChange('email', value)}
                  placeholder="seu@email.com"
                  keyboardType="email-address"
                />
                {emailError ? <Text style={styles.errorText}>{emailError}</Text> : null}
              </View>
              
              <View style={styles.formGroup}>
                <Text style={styles.label}>Assunto *</Text>
                <TextInput
                  style={styles.input}
                  value={formData.assunto}
                  onChangeText={(value) => handleInputChange('assunto', value)}
                  placeholder="Digite o assunto"
                />
              </View>
              
              <View style={styles.formGroup}>
                <Text style={styles.label}>Mensagem *</Text>
                <TextInput
                  style={[styles.input, styles.textarea]}
                  value={formData.mensagem}
                  onChangeText={(value) => handleInputChange('mensagem', value)}
                  placeholder="Digite sua mensagem aqui..."
                  multiline
                  numberOfLines={6}
                  textAlignVertical="top"
                />
              </View>
              
              <TouchableOpacity
                style={styles.checkboxContainer}
                onPress={() => handleInputChange('newsletter', !formData.newsletter)}
              >
                <View style={[styles.checkbox, formData.newsletter && styles.checkboxChecked]}>
                  {formData.newsletter && <Text style={styles.checkmark}>✓</Text>}
                </View>
                <Text style={styles.checkboxLabel}>
                  Quero receber novidades sobre inclusão e neurodiversidade
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.submitBtn} onPress={handleGmailRedirect}>
                <Text style={styles.submitBtnText}>Enviar Mensagem</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* FAQ */}
        <View style={styles.faqSection}>
          <Text style={styles.faqTitle}>Perguntas Frequentes</Text>
          <View style={styles.faqGrid}>
            {faqItems.map((item, index) => (
              <View key={index} style={styles.faqItem}>
                <Text style={styles.faqQuestion}>{item.question}</Text>
                <Text style={styles.faqAnswer}>{item.answer}</Text>
              </View>
            ))}
          </View>
        </View>

        <Footer navigation={navigation} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f7f6',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  contatoIntro: {
    backgroundColor: 'white',
    margin: 20,
    padding: 20,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  contatoTitle: {
    color: '#5e35b1',
    fontSize: width < 768 ? 20 : 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 15,
  },
  contatoDescription: {
    fontSize: width < 768 ? 13 : 14,
    lineHeight: width < 768 ? 20 : 22,
    color: '#333',
    textAlign: 'center',
  },
  contatoContent: {
    margin: 20,
  },
  contatoGrid: {
    flexDirection: width < 768 ? 'column' : 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  contatoInfo: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    marginBottom: 20,
    width: width < 768 ? '100%' : '48%',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  infoTitle: {
    color: '#5e35b1',
    fontSize: width < 768 ? 16 : 18,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  infoItem: {
    marginBottom: 20,
  },
  infoLabel: {
    color: '#5e35b1',
    fontSize: width < 768 ? 13 : 14,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  infoLink: {
    color: '#673ab7',
    fontSize: width < 768 ? 13 : 14,
    textDecorationLine: 'underline',
  },
  infoText: {
    color: '#333',
    fontSize: width < 768 ? 13 : 14,
  },
  contatoForm: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    width: width < 768 ? '100%' : '48%',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  formTitle: {
    color: '#5e35b1',
    fontSize: width < 768 ? 16 : 18,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  formGroup: {
    marginBottom: 15,
  },
  label: {
    color: '#5e35b1',
    fontSize: width < 768 ? 13 : 14,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    padding: width < 768 ? 10 : 12,
    fontSize: width < 768 ? 13 : 14,
    backgroundColor: '#fff',
  },
  textarea: {
    height: 100,
    textAlignVertical: 'top',
  },
  selectContainer: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    backgroundColor: '#fff',
  },
  select: {
    padding: 12,
  },
  selectText: {
    fontSize: width < 768 ? 13 : 14,
    color: '#333',
  },
  placeholderText: {
    color: '#999',
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderWidth: 2,
    borderColor: '#673ab7',
    borderRadius: 4,
    marginRight: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkboxChecked: {
    backgroundColor: '#673ab7',
  },
  checkmark: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  checkboxLabel: {
    fontSize: width < 768 ? 13 : 14,
    color: '#333',
    flex: 1,
  },
  submitBtn: {
    backgroundColor: '#673ab7',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 5,
    alignItems: 'center',
  },
  submitBtnText: {
    color: 'white',
    fontSize: width < 768 ? 14 : 16,
    fontWeight: 'bold',
  },
  faqSection: {
    backgroundColor: 'white',
    margin: 20,
    padding: 20,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  faqTitle: {
    color: '#5e35b1',
    fontSize: width < 768 ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  faqGrid: {
    flexDirection: width < 768 ? 'column' : 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  faqItem: {
    backgroundColor: '#f8f9fa',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    width: width < 768 ? '100%' : '48%',
  },
  faqQuestion: {
    color: '#5e35b1',
    fontSize: width < 768 ? 13 : 14,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  faqAnswer: {
    color: '#333',
    fontSize: width < 768 ? 12 : 13,
    lineHeight: width < 768 ? 16 : 18,
  },
  inputError: {
    borderColor: 'red',
  },
  errorText: {
    color: 'red',
    fontSize: 12,
    marginTop: 5,
  },
});

export default ContatoScreen;

