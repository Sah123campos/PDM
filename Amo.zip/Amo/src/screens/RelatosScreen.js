import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Dimensions 
} from 'react-native';
import Header from '../components/Header';
import Footer from '../components/Footer';

const { width } = Dimensions.get('window');

/** @param {{ navigation: any }} props */
const RelatosScreen = ({ navigation }) => {
  const relatos = [
    {
      nome: 'Leandra Migotto Certeza',
      meta: 'Área: Jornalista | Diagnóstico: Deficiência Física',
      content: '" Eu vivi situações de preconceito, discriminação e capacitismo em todos os empregos pelos quais passei. Os momentos mais dolorosos e que deixam marcas na minha vida, infelizmente, aconteceram dentro de grandes empresas que se diziam lutar por uma suposta ‘inclusão’; e até com empreendedores da área da inclusão que a pouco tempo me ofereceram funções incompatíveis com a minha formação e experiência profissional, além de pagar baixos valores ou pedir que eu escrevesse reportagens sem assinar o meu nome como jornalista!!! São situações que se repetem diariamente."'
    },
    {
      nome: 'Viviane Santos',
      meta: 'Área: Professora | Diagnóstico: Deficiência Visual',
      content: '"No primeiro emprego de Viviane, a empresa além de não adaptar seus equipamentos, não lhe ofereceu seus direitos trabalhistas. "Eles me forneceram um contrato sem vínculos trabalhistas, e na luta por uma oportunidade, eu aceitei", conta a professora. "Fizeram todo o processo de contratação e quando cheguei, era de faz de conta. Não tinha acessibilidade, nem autonomia e nem direitos""'
    },
    {
      nome: 'A.M.B.',
      meta: 'Área: Técnico de logística | Diagnóstico: Deficiência Auditiva',
      content: '"Na empresa onde trabalhei  passei por muita coisa. Era chamado de preguiçoso e com vários palavrões, por um supervisor, que não tinha paciência comigo, pensando que estava ouvindo. Sempre dizia que surdo não gosta de trabalhar e era humilhado na frente dos meus colegas. A direção tinha interesse de renovar o contrato, mas optei por sair, pois não aguentava mais trabalhar em um ambiente em que não era respeitado como cidadão, pela minha deficiência."'
    },
    {
      nome: 'Thales',
      meta: 'Área: Secretário | Diagnóstico: Autismo',
      content: '"grandes desafios é a sensibilidade à luz e ao barulho, que volta e meia obriga que ele saia de um ambiente e se isole. “Antes de compreender completamente minhas limitações, crises sensoriais interrompiam meu expediente, deixando-me acuado e incapaz de funcionar plenamente."'
    }
  ];

  return (
    <View style={styles.container}>
      <Header navigation={navigation} />
      
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Seção de Introdução */}
        <View style={styles.sectionIntro}>
          <Text style={styles.sectionTitle}>Relatos de Experiências</Text>
          <View style={styles.divider} />
          <Text style={styles.sectionDescription}>
            Esta página apresenta um breve relato de capacitismo vivido no mercado de trabalho, mostrando como a discriminação ainda afeta pessoas com deficiência e reforçando a importância da inclusão real.
          </Text>
        </View>

        {/* Relatos Existentes */}
        <View style={styles.relatosGrid}>
          {relatos.map((relato, index) => (
            <View key={index} style={styles.relatoCard}>
              <Text style={styles.relatoTitle}>{relato.nome}</Text>
              <Text style={styles.relatoMeta}>{relato.meta}</Text>
              <Text style={styles.relatoContent}>{relato.content}</Text>
            </View>
          ))}
        </View>

        <Footer navigation={navigation} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f7f6',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  sectionIntro: {
    backgroundColor: 'white',
    margin: 20,
    padding: 20,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  sectionTitle: {
    color: '#5e35b1',
    fontSize: width < 768 ? 20 : 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  divider: {
    width: 60,
    height: 3,
    backgroundColor: '#6C3DF4',
    alignSelf: 'center',
    marginBottom: 15,
    borderRadius: 2,
  },
  sectionDescription: {
    fontSize: width < 768 ? 13 : 14,
    lineHeight: width < 768 ? 20 : 22,
    color: '#333',
    textAlign: 'center',
  },
  relatosGrid: {
    margin: 20,
  },
  relatoCard: {
    backgroundColor: '#f7f3ff',
    borderWidth: 2,
    borderColor: '#b39dff',
    borderRadius: 20,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#6C3DF4',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.07,
    shadowRadius: 12,
    elevation: 2,
  },
  relatoTitle: {
    color: '#6C3DF4',
    fontSize: width < 768 ? 14 : 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  relatoMeta: {
    color: '#7C4DFF',
    fontSize: width < 768 ? 11 : 12,
    marginBottom: 10,
  },
  relatoContent: {
    color: '#333',
    fontSize: width < 768 ? 12 : 13,
    lineHeight: width < 768 ? 16 : 18,
  },
});

export default RelatosScreen;

