import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Dimensions 
} from 'react-native';
import Header from '../components/Header';
import Footer from '../components/Footer';

const { width } = Dimensions.get('window');

/** @param {{ navigation: any }} props */
const CapacitismoScreen = ({ navigation }) => {
  const capacitismoCards = [
    {
      title: 'O que é capacitismo?',
      content: 'Capacitismo é o preconceito, discriminação ou exclusão de pessoas com deficiência, seja por atitudes, práticas institucionais ou barreiras físicas e sociais. Muitas vezes, está presente em comportamentos sutis e na falta de oportunidades iguais.'
    },
    {
      title: 'Como o capacitismo se manifesta no trabalho',
      content: 'O capacitismo pode aparecer em processos seletivos excludentes, falta de acessibilidade, ausência de políticas inclusivas, barreiras atitudinais, falta de oportunidades de crescimento e até mesmo em microagressões diárias.'
    },
    {
      title: 'Exemplos de atitudes capacitistas',
      content: [
        'Subestimar as habilidades de uma pessoa com deficiência',
        'Não oferecer adaptações necessárias',
        'Fazer piadas ou comentários pejorativos',
        'Ignorar a opinião ou preferências da pessoa',
        'Supor que toda deficiência é visível'
      ]
    },
    {
      title: 'Consequências do capacitismo',
      content: 'O capacitismo prejudica a autoestima, limita o desenvolvimento profissional, reduz a diversidade nas equipes e perpetua a exclusão social. Também pode gerar impactos emocionais e psicológicos nas pessoas afetadas.'
    }
  ];

  const discriminacaoItems = [
    {
      icon: '⚖️',
      title: 'Registrar uma denúncia:',
      description: 'no Ministério Público do Trabalho'
    },
    {
      icon: '🏢',
      title: 'Procurar a Defensoria Pública',
      description: ''
    },
    {
      icon: '📞',
      title: 'Buscar orientação:',
      description: 'em sindicatos'
    }
  ];

  return (
    <View style={styles.container}>
      <Header navigation={navigation} />
      
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Seção de Introdução */}
        <View style={styles.sectionIntro}>
          <Text style={styles.sectionTitle}>Capacitismo no Mercado de Trabalho</Text>
          <View style={styles.divider} />
          <Text style={styles.sectionDescription}>
            O capacitismo é uma forma de preconceito e discriminação contra pessoas com deficiência, 
            baseada na ideia de que elas são inferiores ou menos capazes. No mercado de trabalho, 
            o capacitismo pode se manifestar de diversas formas, impactando negativamente a inclusão 
            e o desenvolvimento profissional dessas pessoas.
          </Text>
        </View>

        {/* Cards de Capacitismo */}
        <View style={styles.capacitismoCards}>
          <View style={styles.cardsRow}>
            {capacitismoCards.slice(0, 2).map((card, index) => (
              <View key={index} style={styles.capacitismoCard}>
                <Text style={styles.capacitismoCardTitle}>{card.title}</Text>
                {Array.isArray(card.content) ? (
                  card.content.map((item, idx) => (
                    <Text key={idx} style={styles.capacitismoCardItem}>• {item}</Text>
                  ))
                ) : (
                  <Text style={styles.capacitismoCardText}>{card.content}</Text>
                )}
              </View>
            ))}
          </View>
          
          <View style={styles.cardsRow}>
            {capacitismoCards.slice(2, 4).map((card, index) => (
              <View key={index + 2} style={styles.capacitismoCard}>
                <Text style={styles.capacitismoCardTitle}>{card.title}</Text>
                {Array.isArray(card.content) ? (
                  card.content.map((item, idx) => (
                    <Text key={idx} style={styles.capacitismoCardItem}>• {item}</Text>
                  ))
                ) : (
                  <Text style={styles.capacitismoCardText}>{card.content}</Text>
                )}
              </View>
            ))}
          </View>
        </View>

        {/* Seção de Discriminação */}
        <View style={styles.discriminacaoSection}>
          <Text style={styles.discriminacaoTitle}>
            O que fazer em caso de{'\n'}discriminação?
          </Text>
          <Text style={styles.discriminacaoDesc}>
            Em caso de discriminação ou violação de direitos, você pode:
          </Text>
          
          <View style={styles.discriminacaoList}>
            {discriminacaoItems.map((item, index) => (
              <View key={index} style={styles.discriminacaoItem}>
                <View style={styles.discriminacaoIcon}>
                  <Text style={styles.iconText}>{item.icon}</Text>
                </View>
                <View style={styles.discriminacaoContent}>
                  <Text style={styles.discriminacaoItemTitle}>{item.title}</Text>
                  {item.description ? (
                    <Text style={styles.discriminacaoItemDesc}>{item.description}</Text>
                  ) : null}
                </View>
              </View>
            ))}
          </View>
        </View>

        <Footer navigation={navigation} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f7f6',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  sectionIntro: {
    backgroundColor: 'white',
    margin: 20,
    padding: 20,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  sectionTitle: {
    color: '#5e35b1',
    fontSize: width < 768 ? 20 : 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  divider: {
    width: 60,
    height: 3,
    backgroundColor: '#6C3DF4',
    alignSelf: 'center',
    marginBottom: 15,
    borderRadius: 2,
  },
  sectionDescription: {
    fontSize: width < 768 ? 13 : 14,
    lineHeight: width < 768 ? 20 : 22,
    color: '#333',
    textAlign: 'center',
  },
  capacitismoCards: {
    margin: 20,
  },
  cardsRow: {
    flexDirection: 'row',
    marginBottom: 15,
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  capacitismoCard: {
    backgroundColor: '#F7F3FF',
    borderWidth: 2,
    borderColor: '#B39DFF',
    borderRadius: 20,
    padding: 15,
    width: width < 768 ? '100%' : '48%',
    marginBottom: 15,
    shadowColor: '#6C3DF4',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 24,
    elevation: 2,
  },
  capacitismoCardTitle: {
    color: '#6C3DF4',
    fontSize: width < 768 ? 14 : 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  capacitismoCardText: {
    color: '#333',
    fontSize: width < 768 ? 12 : 13,
    lineHeight: width < 768 ? 16 : 18,
  },
  capacitismoCardItem: {
    color: '#333',
    fontSize: width < 768 ? 12 : 13,
    lineHeight: width < 768 ? 16 : 18,
    marginBottom: 3,
  },
  discriminacaoSection: {
    backgroundColor: '#f4f0ff',
    margin: 20,
    padding: 20,
    borderRadius: 28,
    shadowColor: '#6C3DF4',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 2,
  },
  discriminacaoTitle: {
    color: '#6C3DF4',
    fontSize: width < 768 ? 18 : 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  discriminacaoDesc: {
    color: '#666',
    fontSize: width < 768 ? 13 : 14,
    textAlign: 'center',
    marginBottom: 20,
  },
  discriminacaoList: {
    flexDirection: 'column',
  },
  discriminacaoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.7)',
    borderRadius: 16,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#6C3DF4',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 1,
  },
  discriminacaoIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(108,61,244,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  iconText: {
    fontSize: 24,
  },
  discriminacaoContent: {
    flex: 1,
  },
  discriminacaoItemTitle: {
    color: '#222',
    fontSize: width < 768 ? 13 : 14,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  discriminacaoItemDesc: {
    color: '#222',
    fontSize: width < 768 ? 12 : 13,
  },
});

export default CapacitismoScreen;

