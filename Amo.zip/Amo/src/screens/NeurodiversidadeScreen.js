import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Dimensions 
} from 'react-native';
import Header from '../components/Header';
import Footer from '../components/Footer';

const { width } = Dimensions.get('window');

/** @param {{ navigation: any }} props */
const NeurodiversidadeScreen = ({ navigation }) => {
  const tiposNeurodiversidade = [
    {
      title: 'Transtorno do Espectro Autista (TEA)',
      description: 'Caracterizado por diferenças na comunicação social e padrões de comportamento restritos e repetitivos. Pessoas com TEA podem ter habilidades excepcionais em áreas específicas.'
    },
    {
      title: 'TDAH (Transtorno do Déficit de Atenção e Hiperatividade)',
      description: 'Caracterizado por dificuldades de atenção, hiperatividade e impulsividade. Pode trazer criatividade, energia e capacidade de multitarefas.'
    },
    {
      title: 'Dislexia',
      description: 'Diferença na forma como o cérebro processa a linguagem escrita. Pode trazer habilidades visuais e espaciais excepcionais.'
    },
    {
      title: 'Transtorno do Processamento Sensorial',
      description: 'Diferenças na forma como o cérebro processa informações sensoriais. Pode resultar em maior sensibilidade ou menor sensibilidade a estímulos.'
    },
    {
      title: 'Transtorno Bipolar',
      description: 'Caracterizado por mudanças extremas de humor, energia e níveis de atividade. Pessoas com transtorno bipolar podem ter períodos de alta criatividade durante fases de euforia.'
    },
    {
      title: 'Esquizofrenia',
      description: 'Caracterizada por alterações no pensamento, percepção, emoções e comportamento. Indivíduos podem ter formas únicas de perceber o mundo e pensar de maneira não convencional.'
    }
  ];

  const contribuicoes = [
    {
      title: 'Diversidade de pensamento e inovação',
      description: 'Enriquecem o ambiente com diferentes perspectivas e formas de resolver problemas.'
    },
    {
      title: 'Soluções criativas',
      description: 'Trazem abordagens inovadoras para desafios do dia a dia.'
    },
    {
      title: 'Habilidades específicas e talentos únicos',
      description: 'Muitos possuem aptidões excepcionais em áreas como lógica, criatividade, atenção a detalhes ou comunicação.'
    },
    {
      title: 'Sensibilidade para acessibilidade e inclusão',
      description: 'Ajudam a criar ambientes mais acessíveis e acolhedores para todos.'
    },
    {
      title: 'Resiliência e capacidade de adaptação',
      description: 'Superam desafios diários e inspiram equipes com sua determinação.'
    }
  ];

  return (
    <View style={styles.container}>
      <Header navigation={navigation} />
      
      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Seção de Introdução */}
        <View style={styles.sectionIntro}>
          <Text style={styles.sectionTitle}>O que é Neurodiversidade?</Text>
          <View style={styles.divider} />
          <Text style={styles.sectionDescription}>
            Neurodiversidade é um conceito que reconhece e valoriza a diversidade natural do cérebro humano. 
            Assim como a biodiversidade é essencial para a natureza, a neurodiversidade é fundamental para a 
            sociedade humana. O termo foi cunhado pela socióloga Judy Singer na década de 1990 e representa 
            uma mudança de paradigma: em vez de ver condições neurológicas como "transtornos" ou "doenças", 
            a neurodiversidade as considera como variações naturais do cérebro humano.
          </Text>
        </View>

        {/* Tipos de Neurodiversidade */}
        <View style={styles.tiposSection}>
          <Text style={styles.sectionSubtitle}>Algumas Neurodiversidades</Text>
          <View style={styles.cardsContainer}>
            {tiposNeurodiversidade.map((tipo, index) => (
              <View key={index} style={styles.card}>
                <View style={styles.cardIcon}>
                  <Text style={styles.iconText}>🧠</Text>
                </View>
                <Text style={styles.cardTitle}>{tipo.title}</Text>
                <Text style={styles.cardDescription}>{tipo.description}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Contribuições */}
        <View style={styles.contribuicoesSection}>
          <Text style={styles.sectionSubtitle}>Contribuições de PCDs e Neurodivergentes</Text>
          <View style={styles.cardsContainer}>
            {contribuicoes.map((contribuicao, index) => (
              <View key={index} style={styles.card}>
                <View style={styles.cardIcon}>
                  <Text style={styles.iconText}>✨</Text>
                </View>
                <Text style={styles.cardTitle}>{contribuicao.title}</Text>
                <Text style={styles.cardDescription}>{contribuicao.description}</Text>
              </View>
            ))}
          </View>
        </View>

        <Footer navigation={navigation} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f7f6',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  sectionIntro: {
    backgroundColor: 'white',
    margin: 20,
    padding: 20,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  sectionTitle: {
    color: '#5e35b1',
    fontSize: width < 768 ? 20 : 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  divider: {
    width: 60,
    height: 3,
    backgroundColor: '#6C3DF4',
    alignSelf: 'center',
    marginBottom: 15,
    borderRadius: 2,
  },
  sectionDescription: {
    fontSize: width < 768 ? 13 : 14,
    lineHeight: width < 768 ? 20 : 22,
    color: '#333',
    textAlign: 'center',
  },
  tiposSection: {
    backgroundColor: '#f4f7f6',
    margin: 20,
    padding: 20,
    borderRadius: 8,
  },
  contribuicoesSection: {
    backgroundColor: 'white',
    margin: 20,
    padding: 20,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  sectionSubtitle: {
    color: '#5e35b1',
    fontSize: width < 768 ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  cardsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  card: {
    backgroundColor: '#f7f3ff',
    borderWidth: 2,
    borderColor: '#b39dff',
    borderRadius: 14,
    padding: 15,
    marginBottom: 15,
    width: width < 768 ? '100%' : '48%',
    shadowColor: '#6C3DF4',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 2,
  },
  cardIcon: {
    width: 50,
    height: 50,
    backgroundColor: 'rgba(108,61,244,0.1)',
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    marginBottom: 10,
  },
  iconText: {
    fontSize: 24,
  },
  cardTitle: {
    color: '#6C3DF4',
    fontSize: width < 768 ? 14 : 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
    lineHeight: width < 768 ? 18 : 20,
  },
  cardDescription: {
    color: '#333',
    fontSize: width < 768 ? 12 : 13,
    lineHeight: width < 768 ? 16 : 18,
    textAlign: 'center',
  },
});

export default NeurodiversidadeScreen;

