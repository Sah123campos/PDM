import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView,
  Dimensions,
  Image
} from 'react-native';
import Header from '../components/Header';
import Footer from '../components/Footer';

const { width } = Dimensions.get('window');

/** @param {{ navigation: any }} props */
const SobreScreen = ({ navigation }) => {


  return (
    <View style={{flex: 1, backgroundColor: '#f4f7f6'}}>
      <Header navigation={navigation} />
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, {flexGrow: 1, justifyContent: 'space-between'}]}
        showsVerticalScrollIndicator={false}
      >
        <View style={{flex: 1}}>
          <View style={styles.aboutSection}>
            <Image source={require('../styles/logo.png')} style={styles.logo} resizeMode="contain" />
            <Text style={styles.aboutTitle}>Sobre o Projeto NeuroInclusão</Text>
            <Text style={styles.aboutText}>
              O site NeuroInclusão foi criado por Laura, Leonardo, Samuel com o propósito de auxiliar pessoas com
              deficiência e neurodivergentes, além de apoiar empresas e órgãos públicos interessados em
              compreender melhor essas temáticas no contexto do mercado de trabalho.
            </Text>
            <Text style={styles.aboutText}>
              Muitas pessoas neurodivergentes e com deficiência relatam o peso diário do capacitismo — uma
              forma de discriminação que desvaloriza ou limita suas capacidades com base em preconceitos e
              padrões normativos. Esse preconceito, muitas vezes sutil ou institucionalizado, dificulta o acesso à
              educação, à empregabilidade, ao crescimento profissional e até ao reconhecimento de suas
              competências. A NeuroInclusão nasce como um espaço de escuta, informação e transformação,
              tendo o objetivo é promover conscientização, combater o capacitismo e construir pontes entre
              talentos diversos e ambientes profissionais mais justos e acessíveis.
            </Text>
            <Text style={styles.aboutText}>
              Acreditamos que a diversidade não é apenas uma questão de justiça social, mas uma fonte de
              inovação, sensibilidade e potência coletiva. A NeuroInclusão é, portanto, um convite à escuta, ao
              aprendizado e à mudança.
            </Text>
          </View>
        </View>
        <Footer navigation={navigation} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f7f6',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  aboutSection: {
    backgroundColor: 'white',
    margin: 20,
    padding: 30,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  aboutTitle: {
    color: '#5e35b1',
    fontSize: width < 768 ? 20 : 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  aboutText: {
    fontSize: width < 768 ? 13 : 14,
    lineHeight: width < 768 ? 20 : 22,
    marginBottom: 15,
    color: '#555',
    textAlign: 'justify',
  },
  logo: {
    width: '70%',
    maxWidth: 320,
    height: 140,
    alignSelf: 'center',
    marginBottom: 14,
  },
});

export default SobreScreen;

