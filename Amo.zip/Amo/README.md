# NeuroInclusão - App React Native

Este é um aplicativo React Native que foi convertido a partir de um site HTML sobre neurodiversidade e inclusão de pessoas com deficiência no mercado de trabalho.

## 📱 Funcionalidades

- **Tela Inicial**: Apresentação do projeto e navegação principal
- **Neurodiversidade**: Informações sobre diferentes tipos de neurodiversidade e suas contribuições
- **Legislação**: Leis e direitos das pessoas com deficiência no Brasil
- **Capacitismo**: Informações sobre preconceito e discriminação, com orientações sobre como agir
- **Relatos**: Histórias reais de pessoas neurodivergentes e formulário para compartilhar experiências
- **Desafios**: Estatísticas, desafios enfrentados e estratégias para inclusão
- **Sobre**: Informações sobre o projeto e seu criador
- **Contato**: Formulário de contato e perguntas frequentes

## 🚀 Como Executar

### Pré-requisitos

- Node.js (versão 16 ou superior)
- npm ou yarn
- Expo CLI instalado globalmente (`npm install -g @expo/cli`)
- Expo Go app no seu dispositivo móvel (para testar)

### Instalação

1. Clone ou baixe o projeto
2. Navegue até a pasta do projeto:
   ```bash
   cd Amo
   ```

3. Instale as dependências:
   ```bash
   npm install
   ```

4. Inicie o projeto:
   ```bash
   npm start
   ```

5. Use o Expo Go app para escanear o QR code que aparecerá no terminal

## 📁 Estrutura do Projeto

```
src/
├── components/
│   ├── Header.js          # Cabeçalho com navegação
│   └── Footer.js          # Rodapé com informações de contato
├── screens/
│   ├── HomeScreen.js      # Tela inicial
│   ├── NeurodiversidadeScreen.js
│   ├── LegislacaoScreen.js
│   ├── CapacitismoScreen.js
│   ├── RelatosScreen.js
│   ├── DesafiosScreen.js
│   ├── SobreScreen.js
│   └── ContatoScreen.js
└── styles/                # Estilos compartilhados (futuro)
```

## 🎨 Design

O app mantém a identidade visual do site original com:
- Cores principais: Roxo (#673ab7) e Azul (#03a9f4)
- Design responsivo que se adapta a diferentes tamanhos de tela
- Componentes reutilizáveis para consistência visual
- Navegação intuitiva entre as telas

## 📱 Navegação

O app utiliza React Navigation com stack navigator para navegação entre as telas. Cada tela é acessível através do menu no cabeçalho.

## 🔧 Tecnologias Utilizadas

- **React Native**: Framework para desenvolvimento mobile
- **Expo**: Plataforma para desenvolvimento React Native
- **React Navigation**: Biblioteca de navegação
- **React Hooks**: Para gerenciamento de estado local

## 📝 Funcionalidades Implementadas

- ✅ Navegação entre todas as telas
- ✅ Formulários funcionais (Relatos e Contato)
- ✅ Links funcionais (email e telefone)
- ✅ Design responsivo
- ✅ Componentes reutilizáveis
- ✅ Validação de formulários
- ✅ Alertas de confirmação

## 🚧 Melhorias Futuras

- [ ] Adicionar animações entre telas
- [ ] Implementar modo escuro
- [ ] Adicionar notificações push
- [ ] Integrar com backend para salvar relatos
- [ ] Adicionar mais recursos de acessibilidade
- [ ] Implementar cache offline

## 📞 Contato

Para dúvidas ou sugestões sobre o projeto, entre em contato através do formulário na tela de Contato do app.

---

**Desenvolvido com ❤️ para promover a inclusão e neurodiversidade no mercado de trabalho.**

