import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';

// Importar as telas
import HomeScreen from './src/screens/HomeScreen';
import NeurodiversidadeScreen from './src/screens/NeurodiversidadeScreen';
import LegislacaoScreen from './src/screens/LegislacaoScreen';
import CapacitismoScreen from './src/screens/CapacitismoScreen';
import RelatosScreen from './src/screens/RelatosScreen';
import DesafiosScreen from './src/screens/DesafiosScreen';
import SobreScreen from './src/screens/SobreScreen';
import ContatoScreen from './src/screens/ContatoScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="auto" />
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerStyle: {
            backgroundColor: '#673ab7',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      >
        <Stack.Screen 
          name="Home" 
          component={HomeScreen} 
          options={{ headerShown: false }}
        />
        <Stack.Screen 
          name="Neurodiversidade" 
          component={NeurodiversidadeScreen} 
          options={{ headerShown: false }}
        />
        <Stack.Screen 
          name="Legislacao" 
          component={LegislacaoScreen} 
          options={{ headerShown: false }}
        />
        <Stack.Screen 
          name="Capacitismo" 
          component={CapacitismoScreen} 
          options={{ headerShown: false }}
        />
        <Stack.Screen 
          name="Relatos" 
          component={RelatosScreen} 
          options={{ headerShown: false }}
        />
        <Stack.Screen 
          name="Desafios" 
          component={DesafiosScreen} 
          options={{ headerShown: false }}
        />
        <Stack.Screen 
          name="Sobre" 
          component={SobreScreen} 
          options={{ headerShown: false }}
        />
        <Stack.Screen 
          name="Contato" 
          component={ContatoScreen} 
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
